﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using Entity;
using CustomException;
using BusinessLogicLayer;
using System.Data.SqlClient;

namespace PresentationLayer
{
    public partial class Form1 : Form
    {
        GuestValidation validationsObj = new GuestValidation();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        //To add the record
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Guest guestObj = new Guest();
                bool isNumber;
                int result;
                long contactNo;
                isNumber = int.TryParse(txtGuestID.Text, out result);
                if (isNumber)
                    guestObj.GuestID = result;
                else
                {
                    MessageBox.Show("Please enter only numbers in Guest ID field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                guestObj.GuestName = txtGuestName.Text;
                isNumber = long.TryParse(txtContactNo.Text, out contactNo);
                if (isNumber)
                    guestObj.ContactNo = contactNo;
                else
                {
                    MessageBox.Show("Please enter only numbers in Conatct No field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }


                bool guestAdded = validationsObj.AddGuestRecord(guestObj);
                if (guestAdded)
                {
                    MessageBox.Show("Guest Added Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtGuestID.Clear();
                    txtGuestName.Clear();
                    txtContactNo.Clear();
                }
                else
                    MessageBox.Show("Failed to add guest record", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (GuestException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        //To display
        private void button2_Click(object sender, EventArgs e)
        {
            DataTable guestTable = new DataTable();
            guestTable = validationsObj.DisplayGuestRecord();
            dgvGuest.DataSource = guestTable;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        //To search the record
        private void button3_Click(object sender, EventArgs e)
        {
            DataTable guestTable = new DataTable();
            bool isNumber;
            int result;
            isNumber = int.TryParse(txtGuestID.Text, out result);
            if (isNumber)
            {
                guestTable = validationsObj.GetGuestRecord(result);
                txtGuestID.Clear();
                //txtGuestName.Clear();
                //txtContactNo.Clear();
            }
            else
            {
                MessageBox.Show("Please enter only numbers in Guest ID field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            dgvGuest.DataSource = guestTable;
        }

        //To update
        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                Guest guestObj = new Guest();
                bool isNumber;
                int result;
                long contactNo;
                isNumber = int.TryParse(txtGuestID.Text, out result);
                if (isNumber)
                    guestObj.GuestID = result;
                else
                {
                    MessageBox.Show("Please enter only numbers in Guest ID field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                guestObj.GuestName = txtGuestName.Text;
                isNumber = long.TryParse(txtContactNo.Text, out contactNo);
                if (isNumber)
                    guestObj.ContactNo = contactNo;
                else
                {
                    MessageBox.Show("Please enter only numbers in Conatct No field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }


                bool guestUpdated = validationsObj.UpdateGuestRecord(guestObj);
                if (guestUpdated)
                {
                    MessageBox.Show("Guest Updated Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtGuestID.Clear();
                    txtGuestName.Clear();
                    txtContactNo.Clear();
                }
                else
                    MessageBox.Show("Failed to update guest record", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (GuestException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //To delete
        private void button4_Click(object sender, EventArgs e)
        {        
            bool isNumber;
            int result;
            isNumber = int.TryParse(txtGuestID.Text, out result);
            if (isNumber)
            {
                validationsObj.DeleteGuestRecord(result);
                MessageBox.Show("Guest Deleted Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtGuestID.Clear();
            }
            else
            {
                MessageBox.Show("Record cannot be deleted", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

       

    }
}
