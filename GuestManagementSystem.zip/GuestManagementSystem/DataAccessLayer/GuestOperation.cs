﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using Entity;
using CustomException;

namespace DataAccessLayer
{
    public class GuestOperation
    {
        SqlConnection connection;
        SqlDataReader reader;
       
        public GuestOperation()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["GMS"].ConnectionString;
            connection = new SqlConnection(connectionString);
        }

       //Method for adding
        public bool AddGuestRecord(Guest guestObj)
        {
            try
            {
                bool guestAdded = false;
                SqlCommand cmdAdd = new SqlCommand("AddGuest_121824", connection);
                cmdAdd.CommandType = CommandType.StoredProcedure;
                cmdAdd.Parameters.AddWithValue("@GuestID", guestObj.GuestID);
                cmdAdd.Parameters.AddWithValue("@GuestName", guestObj.GuestName);
                cmdAdd.Parameters.AddWithValue("@ContactNo", guestObj.ContactNo);
                connection.Open();
                int result = cmdAdd.ExecuteNonQuery();
                if (result > 0)
                    guestAdded = true;
                return guestAdded;
            }
            catch (GuestException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

        //Method for displaying all the result
        public DataTable DisplayGuestRecord()
        {
            SqlCommand cmdDisplay = new SqlCommand("GetAllGuests_121824", connection);
            cmdDisplay.CommandType = CommandType.StoredProcedure;
            if (connection.State == ConnectionState.Closed)
                connection.Open();
            reader = cmdDisplay.ExecuteReader();
            DataTable guestTable = new DataTable();
            guestTable.Load(reader);
            return guestTable;
            connection.Close();
        }

        //Method for search
        public DataTable GetGuestRecord(int guestID)
        {
            try
            {
                SqlCommand cmdGetGuest = new SqlCommand("RetrieveGuestInfo_121824", connection);
                cmdGetGuest.CommandType = CommandType.StoredProcedure;
                cmdGetGuest.Parameters.AddWithValue("@GuestID", guestID);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                reader = cmdGetGuest.ExecuteReader();
                DataTable guestTable = new DataTable();
                guestTable.Load(reader);
                return guestTable;
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
          
            
        }

        //Method for updating the guest record
        public bool UpdateGuestRecord(Guest guestObj)
        {
            bool guestUpdated = false;

            try
            {
                SqlCommand cmdUpdate = new SqlCommand("UpdateGuestInfo_121824", connection);
                cmdUpdate.CommandType = CommandType.StoredProcedure;
                cmdUpdate.Parameters.AddWithValue("@GuestID", guestObj.GuestID);
                cmdUpdate.Parameters.AddWithValue("@GuestName", guestObj.GuestName);
                cmdUpdate.Parameters.AddWithValue("@ContactNo", guestObj.ContactNo);
                connection.Open();
                int result = cmdUpdate.ExecuteNonQuery();
                if (result > 0)
                    guestUpdated = true;
                return guestUpdated;
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            finally
            {
                connection.Close();
            }
        }

        //Method for deleting the guest record
        public bool DeleteGuestRecord(int guestID)
        {
            bool guestDeleted = false;

            try
            {
               SqlCommand cmdDelete = new SqlCommand("DeleteGuestInfo_121824", connection);
               cmdDelete.CommandType = CommandType.StoredProcedure;
               cmdDelete.Parameters.AddWithValue("@GuestID", guestID);
              
                connection.Open();
                int result = cmdDelete.ExecuteNonQuery();
                if (result > 0)
                    guestDeleted = true;
             
                else
                {
                    throw new GuestException("Guest not found for Deletion");
                }
                return guestDeleted;
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            finally
            {
                connection.Close();
            }
        }

    }
}
